<div class="table-responsive">
    <table class="table table-hover">
        <thead class="thead-light">
            <tr>
                <th scope="col">Titre</th>
                <th scope="col">Limite</th>
                <th scope="col"></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $logements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr id="<?php echo e($logement->id); ?>">
                    <td><?php echo e($logement->title); ?></td>
                    <td class="date-id"><?php echo e(date_create($logement->limit)->format('d-m-Y')); ?></td>
                    <td class="float-right">
                        <a class="btn btn-primary btn-sm" href="<?php echo e(route('logements.show', $logement->id)); ?>" target="_blank" role="button" data-toggle="tooltip" title="Voir le logement"><i class="fas fa-eye"></i></a>
                        <?php if(isset($edit)): ?>
                            <a class="btn btn-warning btn-sm" href="<?php echo e(route('logements.edit', $logement->id)); ?>" role="button" data-toggle="tooltip" title="Modifier le logement"><i class="fas fa-edit"></i></a>
                        <?php endif; ?>
                        <i class="fas fa-spinner fa-pulse fa-lg" style="display: none"></i>
                        <?php if(empty($noAdd)): ?>
                            <a class="btn btn-success btn-sm" href="<?php echo e(route('user.addweek', $logement->id)); ?>" role="button" data-id="<?php echo e($logement->id); ?>" data-toggle="tooltip" title="Ajouter une semaine"><i class="fas fa-arrow-alt-circle-up"></i></a>
                        <?php endif; ?>
                        <a class="btn btn-danger btn-sm" href="<?php echo e(route('user.destroy', $logement->id)); ?>" role="button" data-id="<?php echo e($logement->id); ?>" data-toggle="tooltip" title="Supprimer le logement"><i class="fas fa-trash"></i></a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<div class="d-flex">
    <div class="mx-auto">
        <?php echo e($logements->links()); ?>

    </div>
</div><?php /**PATH C:\wamp\www\ledemarcheur\resources\views/partials/table-add-del-view.blade.php ENDPATH**/ ?>