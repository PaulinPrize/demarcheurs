<div class="row">
    <?php $__currentLoopData = $logements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-lg-6">
        <a href="<?php echo e(route('logements.show', $logement->id)); ?>" class="blockAd">
            <div class="card d-flex flex-row">
                <div class="card-header">
                    <?php if($logement->photos->isNotEmpty()): ?>  
                        <img class="rounded" src="<?php echo e(asset('public/thumbs/' . $logement->photos->first()->filename)); ?>" alt="">
                    <?php else: ?>
                        <img src="<?php echo e(asset('public/thumbs/question.jpg')); ?>" alt="">
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <h4 class="card-title"><?php echo e($logement->title); ?></h4>
                    <p class="card-text"><?php echo e($logement->category->name); ?></p>
                    <p class="card-text">
                        testo<br>
                        <?php echo e($logement->created_at->calendar()); ?>

                    </p>
                </div>
            </div>
        </a>
        <br>  
    </div>  
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="d-flex">
    <div class="mx-auto">
        <?php echo e($logements->links()); ?>

    </div>
</div><?php /**PATH C:\wamp\www\ledemarcheur\resources\views/partials/annoncesEnCours.blade.php ENDPATH**/ ?>