<?php $__env->startSection('content'); ?>
    <div class="container">
        <div id="massageOk" class="alert alert-success" role="alert" style="display: none">
            Votre message a été pris en compte et sera envoyé rapidement
        </div>

        <?php echo $__env->make('partials.message', ['url' => route('message')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="card bg-light">
            <h5 class="card-header"><?php echo e($logement->title); ?></h5>
            <?php if($photos->isNotEmpty()): ?>
                <?php if($photos->count() > 1): ?>
                    <div id="ctrl" class="carousel slide" data-ride="carousel">
                        <ol class="carousel-indicators">
                            <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li data-target="#ctrl" data-slide-to="<?php echo e($loop->index); ?>" <?php if($loop->first): ?> class="active" <?php endif; ?>></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ol>
                        <div class="carousel-inner">
                            <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="carousel-item <?php if($loop->first): ?> active <?php endif; ?>">
                                    <img class="d-block w-100" src="<?php echo e(asset('public/images/' . $photo->filename)); ?>" alt="First slide">
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <a class="carousel-control-prev" href="#ctrl" role="button" data-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="sr-only">Précédent</span>
                        </a>
                        <a class="carousel-control-next" href="#ctrl" role="button" data-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="sr-only">Suivant</span>
                        </a>
                    </div>
                <?php else: ?>
                    <img class="card-img-top" src="<?php echo e(asset('public/images/' . $logement->photos->first()->filename)); ?>">
                <?php endif; ?>
            <?php endif; ?>
            <div class="card-body">
                <hr>
                <p><u>Description :</u></p>
                <p class="card-text"><?php echo e($logement->texte); ?></p>
                <hr>
                <p class="card-text"><u>Catégorie</u> : <?php echo e($logement->category->name); ?></p>
                <p class="card-text">
                    <u>Région</u> : <?php echo e($logement->region->name); ?> <br>
                    <u>Publication</u> : <?php echo e($logement->created_at->calendar()); ?>

                </p>
                <hr>
                <p class="card-text">
                    <u>Prix</u> : <?php echo e($logement->prix); ?> F CFA<br>
                    <u>Commission</u> : <?php echo e($logement->commission); ?> F CFA<br>
                    <u>Frais de visite</u> : <?php echo e($logement->frais_de_visite); ?> F CFA<br>
                </p>
                <hr>
                <p class="card-text"><u>Pseudo</u> : <?php echo e($logement->pseudo); ?></p>
                <hr>
                <button id="openModal" type="button" class="btn btn-warning" style="color:white;">Envoyer un message</button>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(() => {
            const toggleButtons = () => {
                $('#icon').toggle();
                $('#buttons').toggle();
            }

            $('#openModal').click(() => {
                $('#messageModal').modal();
            });

            $('#messageForm').submit((e) => {
                let that = e.currentTarget;
                e.preventDefault();
                $('#message').removeClass('is-invalid');
                $('.invalid-feedback').html('');
                toggleButtons();
                $.ajax({
                    method: $(that).attr('method'),
                    url: $(that).attr('action'),
                    data: $(that).serialize()
                })
                .done((data) => {
                    toggleButtons();
                    $('#messageModal').modal('hide');
                    $('#massageOk').text(data.info).show();
                })
                .fail((data) => {
                    toggleButtons();
                    $.each(data.responseJSON.errors, function (i, error) {
                        $(document)
                            .find('[name="' + i + '"]')
                            .addClass('is-invalid')
                            .next()
                            .append(error[0]);
                    });
                });
            });
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u157367351/domains/demarcheurs.com/public_html/resources/views/logement/afficher-logement.blade.php ENDPATH**/ ?>