<?php $__env->startSection('content'); ?>
	<div class="card bg-light">
		<h3 class="card-header">Modifier la  catégorie</h3>
		<div class="card-body">
			<form method="POST" action="<?php echo e(route('categorie.update', $categorie->id)); ?>">
				<?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                <div class="row">
					<div class="form-group col-md-12">
                		<label for="name">Nom de la catégorie *</label>
                		<input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e($categorie->name); ?>"/>
                		<?php if($errors->has('name')): ?>
        					<div class="invalid-feedback">
            					<?php echo e($errors->first('name')); ?>

        					</div>
    					<?php endif; ?>
                	</div>
				</div>
				<button type="submit" class="btn btn-warning " style="color:white;">Enregistrer</button>
			</form>
		</div>
		
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\ledemarcheur\resources\views/categorie/modifier.blade.php ENDPATH**/ ?>