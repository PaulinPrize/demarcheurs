<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('partials.message', ['url' => route('user.refuse')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.alerts', ['title' => 'Logements à modérer'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="table-responsive">
        <table class="table table-hover">
            <thead class="thead-light">
                <tr>
                    <th scope="col">Titre</th>
                    <th scope="col"></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $adModeration; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr id="<?php echo e($logement->id); ?>">
                        <td><?php echo e($logement->title); ?></td>
                        <td class="float-right">
                            <a class="btn btn-primary btn-sm" href="<?php echo e(route('logements.show', $logement->id)); ?>" target="_blank" role="button" data-toggle="tooltip" title="Voir le logement">
                                <i class="fas fa-eye"></i>
                            </a>
                            <a class="btn btn-success btn-sm" href="<?php echo e(route('user.approve', $logement->id)); ?>" role="button" data-toggle="tooltip" title="Approuver le logement">
                                <i class="fas fa-thumbs-up"></i>
                            </a>
                            <i class="fas fa-spinner fa-pulse fa-lg" style="display: none"></i>
                            <a class="btn btn-danger btn-sm" href="#" role="button" data-id="<?php echo e($logement->id); ?>" data-toggle="tooltip" title="Refuser le logement">
                                <i class="fas fa-thumbs-down"></i>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div class="d-flex">
        <div class="mx-auto">
            <?php echo e($adModeration->links()); ?>

        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <?php echo $__env->make('partials.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\ledemarcheur\resources\views/user/moderer.blade.php ENDPATH**/ ?>