<?php $__env->startSection('content'); ?>
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Toutes les régions</h1>
    </div>
    <div class="table-responsive">
        <table class="table table-hover">
            <thead class="thead-light">
                <tr>
                    <th scope="col">Nom</th>
                    <th scope="col">Slug</th>
                    <th scope="col">Code</th>
                    <th scope="col">Date de création</th>
                    <th scope="col">Date de modification</th>
                    <th scope="col"></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr id="<?php echo e($region->id); ?>"> 
                        <td><?php echo e($region->name); ?></td>
                        <td><?php echo e($region->slug); ?></td>
                        <td><?php echo e($region->code); ?></td>
                        <td><?php echo e($region->created_at); ?></td>
                        <td><?php echo e($region->updated); ?></td>
                        <td class="float-right">
                            <a class="btn btn-primary btn-sm" href="<?php echo e(route('region.show', $region->id)); ?>" target="_blank" role="button" data-toggle="tooltip" title="Voir la région">
                                <i class="fas fa-eye"></i>
                            </a>                           
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div class="d-flex">
        <div class="mx-auto">
            <?php echo e($regions->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <?php echo $__env->make('partials.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u157367351/domains/demarcheurs.com/public_html/resources/views/region/toutes-les-regions.blade.php ENDPATH**/ ?>