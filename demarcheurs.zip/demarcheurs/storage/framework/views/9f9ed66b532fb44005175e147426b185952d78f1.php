<?php $__env->startSection('content'); ?>
<div id="app">
    <?php if($region): ?>
        <div id="start"
            data-id="<?php echo e($region->id); ?>"
            data-code="<?php echo e($region->code); ?>"
            data-slug="<?php echo e($region->slug); ?>"
        
    <?php else: ?>
        <div id="start" data-id="0"
    <?php endif; ?>
    <?php if($page != 0): ?>
        data-page="<?php echo e($page); ?>"
    <?php endif; ?>
    ></div>
    <ad
        url="<?php echo e(route('logements.search')); ?>"
        :categories="<?php echo e($categories); ?>"
        :regions="<?php echo e($regions); ?>"
        ref="adComp"
    ></ad>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('public/js/vue.js')); ?>"></script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ledemarcheur\resources\views/logement/adsvue.blade.php ENDPATH**/ ?>