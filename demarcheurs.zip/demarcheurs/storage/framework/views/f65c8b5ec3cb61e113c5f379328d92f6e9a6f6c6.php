<script src="<?php echo e(asset('public/js/sb-admin-2.js')); ?>"></script>
<script>
    $(function () {
        $('[data-toggle="tooltip"]').tooltip();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    })
</script>
<?php echo $__env->yieldContent('script'); ?>
</body>
</html><?php /**PATH C:\wamp\www\ledemarcheur\resources\views/layouts/footer.blade.php ENDPATH**/ ?>