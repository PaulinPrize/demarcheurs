<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.message', ['url' => route('user.message.refuse')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.alerts', ['title' => 'Messages à modérer'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="table-responsive">
        <table class="table table-hover">
            <thead class="thead-light">
                <tr>
                    <th scope="col">Email</th>
                    <th scope="col">Texte</th>
                    <th scope="col"></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr id="<?php echo e($message->id); ?>">
                        <td><?php echo e($message->email); ?></td>
                        <td><?php echo e($message->texte); ?></td>
                        <td class="float-right">
                            <a class="btn btn-success btn-sm" href="<?php echo e(route('user.message.approve', $message->id)); ?>" role="button" data-toggle="tooltip" title="Approuver le message"><i class="fas fa-thumbs-up"></i></a>
                            <i class="fas fa-spinner fa-pulse fa-lg" style="display: none"></i>
                            <a class="btn btn-danger btn-sm" href="#" role="button" data-id="<?php echo e($message->id); ?>" data-toggle="tooltip" title="Refuser le message"><i class="fas fa-thumbs-down"></i></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div class="d-flex">
        <div class="mx-auto">
            <?php echo e($messages->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <?php echo $__env->make('partials.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u157367351/domains/demarcheurs.com/public_html/resources/views/user/messages-en-attente.blade.php ENDPATH**/ ?>