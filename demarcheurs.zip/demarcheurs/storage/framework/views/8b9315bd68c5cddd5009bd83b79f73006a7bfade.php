<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="jumbotron">
            <div class="row">
                <div class="col-md-4">
                    <img src="<?php echo e(asset('public/img/speaker.png')); ?>" alt="">
                </div>
                <div class="col-md-8">
                    <h1 class="display-4">Bravo</h1>
                    <p class="lead">Votre logement a bien été pris en compte, et sera publié après modération.</p>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u157367351/domains/demarcheurs.com/public_html/resources/views/logement/confirmer-logement.blade.php ENDPATH**/ ?>