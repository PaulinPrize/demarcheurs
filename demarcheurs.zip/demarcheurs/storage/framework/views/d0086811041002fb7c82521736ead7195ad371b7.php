<?php $__env->startSection('content'); ?>
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Toutes les catégories</h1>
    </div>
    <div class="table-responsive">
        <table class="table table-hover">
            <thead class="thead-light">
                <tr>
                    <th scope="col">Nom</th>
                    <th scope="col">Date de création</th>
                    <th scope="col">Date de modification</th>
                    <th scope="col"></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr id="<?php echo e($categorie->id); ?>"> 
                        <td><?php echo e($categorie->name); ?></td>
                        <td><?php echo e($categorie->created_at); ?></td>
                        <td><?php echo e($categorie->updated_at); ?></td>
                        <td class="float-right">
                            <a class="btn btn-primary btn-sm" href="<?php echo e(route('categorie.show', $categorie->id)); ?>" target="_blank" role="button" data-toggle="tooltip" title="Voir la catégorie">
                                <i class="fas fa-eye"></i>
                            </a>
                            <a class="btn btn-warning btn-sm" href="<?php echo e(route('categorie.edit',$categorie->id)); ?>" arget="_blank" role="button" data-toggle="tooltip" title="Modifier la catégorie">
                                <i class="fas fa-edit"></i>
                            </a>
                            <a class="btn btn-danger btn-sm" href="<?php echo e(route('categorie.destroy', $categorie->id)); ?>" role="button" data-id="<?php echo e($categorie->id); ?>" data-toggle="tooltip" title="Supprimer la catégorie"><i class="fas fa-trash"></i>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <a href="<?php echo e(route('categorie.create')); ?>" class=" btn btn-md btn-warning">
        Ajouter
    </a>
    <div class="d-flex">
        <div class="mx-auto">
            <?php echo e($categories->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <?php echo $__env->make('partials.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ledemarcheur\resources\views/categorie/toutes-les-categories.blade.php ENDPATH**/ ?>