<?php $__env->startSection('content'); ?>
<div>
    <div class="container">
        <div class="card bg-light">
            <h5 class="card-header"><?php echo e($logement->title); ?></h5>
            <?php echo e($test); ?>

            <?php echo e($photos); ?>

            <?php echo e($logement); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ledemarcheur\resources\views/afficher_logement.blade.php ENDPATH**/ ?>