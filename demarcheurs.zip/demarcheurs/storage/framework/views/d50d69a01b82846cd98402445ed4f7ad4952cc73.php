<?php $__env->startSection('content'); ?>
	<div class="card bg-light">
		<h3 class="card-header">Informations sur la catégorie</h3>
		<div class="card-body">
			<p>ID : <?php echo e($categorie->id); ?></p>
			<p>Nom : <?php echo e($categorie->name); ?></p>
            <p>Date de création : <?php echo e($categorie->created_at); ?></p>
            <p>Dernière modification : <?php echo e($categorie->updated_at); ?></p>
		</div>
	</div>
	<br/>
	<a href="<?php echo e(route('categorie.index')); ?>" class="btn btn-md btn-warning">
        Retourner à la liste
    </a>	
<?php $__env->stopSection(); ?>







<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\ledemarcheur\resources\views/categorie/afficher.blade.php ENDPATH**/ ?>