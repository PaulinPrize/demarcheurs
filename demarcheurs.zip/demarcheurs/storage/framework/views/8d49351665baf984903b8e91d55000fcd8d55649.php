<div class="modal fade" id="messageModal" tabindex="-1" role="dialog" aria-labelledby="message" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <form id="messageForm" method="POST" action="<?php echo e($url); ?>">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <?php if(auth()->guard()->guest()): ?>
                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                            Vous n'êtes pas connecté. Votre message sera modéré avant expédition.
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                    <input id="id" name="id" type="hidden" value="<?php echo e(isset($logement) ? $logement->id : ''); ?>">

                    <div class="form-group">
                        <label for="texte">Entrez ici votre message</label>
                        <textarea class="form-control" id="message" name="message" rows="3" required><?php echo e(old('texte', isset($value) ? $value : '')); ?></textarea>
                        <div id="messageError" class="invalid-feedback"></div>
                    </div>

                    <?php if(auth()->guard()->guest()): ?>
                        <div class="form-group">
                            <label for="email">Votre email pour vous contacter</label>
                            <input type="email" class="form-control" name=email id="email" required>
                            <div id="emailError" class="invalid-feedback"></div>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="modal-footer">
                    <div id="buttons">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-warning" style="color:white">Envoyer</button>
                    </div>
                    <i id="icon" class="fas fa-spinner fa-pulse fa-2x" style="display: none"></i>
                </div>
            </form>
        </div>
    </div>
</div>

<?php /**PATH C:\wamp\www\ledemarcheur\resources\views/partials/message.blade.php ENDPATH**/ ?>