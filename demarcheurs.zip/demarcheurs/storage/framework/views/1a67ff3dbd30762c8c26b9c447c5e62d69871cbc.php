<script src="<?php echo e(asset('public/js/sb-admin-2.js')); ?>"></script>
<script>
    $(function () {
        $('[data-toggle="tooltip"]').tooltip();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    })
</script>
<?php echo $__env->yieldContent('script'); ?>
</body>
</html><?php /**PATH /home/u157367351/domains/demarcheurs.com/public_html/resources/views/layouts/footer.blade.php ENDPATH**/ ?>