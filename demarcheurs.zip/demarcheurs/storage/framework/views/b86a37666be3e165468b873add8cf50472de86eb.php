<?php echo e($slot); ?>

<?php /**PATH /home/u157367351/domains/demarcheurs.com/public_html/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>