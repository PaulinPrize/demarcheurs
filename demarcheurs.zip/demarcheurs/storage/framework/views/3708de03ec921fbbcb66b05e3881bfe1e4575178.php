<?php $__env->startSection('content'); ?>
    <div class="card bg-light">
    	<h3 class="card-header">Ajouter un utilisateur</h3>    
    	<div class="card-body">
    		<form method="POST" action="<?php echo e(route('user.store')); ?>">
    			<div class="row">
    				<div class="form-group col-md-6">
                		<label for="name">Nom *</label>
                		<input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name"/>
                		<?php if($errors->has('name')): ?>
        					<div class="invalid-feedback">
            					<?php echo e($errors->first('name')); ?>

        					</div>
    					<?php endif; ?>
                	</div>
                	<div class="form-group col-md-6">
                		<label for="email">Email *</label>
                		<input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email"/>
                		<?php if($errors->has('email')): ?>
        					<div class="invalid-feedback">
            					<?php echo e($errors->first('email')); ?>

        					</div>
    					<?php endif; ?>
                	</div>
    			</div>
    			<div class="row">
    				<div class="form-group col-md-6">
                		<label for="password">Mot de passe *</label>
                		<input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password"/>
                		<?php if($errors->has('password')): ?>
        					<div class="invalid-feedback">
            					<?php echo e($errors->first('password')); ?>

        					</div>
    					<?php endif; ?>
                	</div>
                	<div class="form-group col-md-6">
                		<label for="confirmation">Confirmer *</label>
                		<input type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="confirmation"/>
                	</div>
    			</div>
    			<div class="row">
    				<div class="form-group col-md-6">
                		<label for="telephone">Téléphone</label>
                		<input id="telephone" type="number" class="form-control<?php echo e($errors->has('telephone') ? ' is-invalid' : ''); ?>" name="telephone"/>
                		<?php if($errors->has('telephone')): ?>
        					<div class="invalid-feedback">
            					<?php echo e($errors->first('telephone')); ?>

        					</div>
    					<?php endif; ?>
                	</div>
                	<div class="form-group col-md-6">
                		<label for="role">Role *</label>
                		<select class="custom-select" name="role" id="role">
                        	<?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            	<option value="<?php echo e($role->id); ?>" <?php if($loop->first): ?> selected <?php endif; ?>><?php echo e($role->name); ?></option>
                        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    	</select>
                	</div>
    			</div>
				<input type="hidden" class="form-control" name="photo" id="photo"  value="images.png"/>
                <button type="submit" class="btn btn-warning float-right" style="color:white;">Enregistrer</button>
    		</form>
    	</div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\ledemarcheur\resources\views/user/ajouter.blade.php ENDPATH**/ ?>